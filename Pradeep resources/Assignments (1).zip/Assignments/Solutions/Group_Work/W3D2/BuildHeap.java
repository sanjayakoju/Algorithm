// Java program for building Heap from Array
package heap;

public class BuildHeap {
static int comparisons=0;
static int swaps =0;
	// To heapify a subtree rooted with node i which is
	// an index in arr[].Nn is size of heap
	static void heapify(int arr[], int n, int i)
	{
		int largest = i; // Initialize largest as root
		int l = 2 * i + 1; // left = 2*i + 1
		int r = 2 * i + 2; // right = 2*i + 2

		// If left child is larger than root
		if (l < n && arr[l] > arr[largest]) {
			comparisons++;
			largest = l;
			swaps++;
		}

		// If right child is larger than largest so far
		if (r < n && arr[r] > arr[largest]) {
			comparisons++;
			largest = r;
			swaps++;
		}
			

		// If largest is not root
		if (largest != i) {
			int swap = arr[i];
			arr[i] = arr[largest];
			arr[largest] = swap;
			
			for (int k = 0; k < n; ++k)
				System.out.print(arr[k] + " ");

			System.out.println();

			// Recursively heapify the affected sub-tree
			heapify(arr, n, largest);
		}
	}

	// Function to build a Max-Heap from the Array
	static void buildHeap(int arr[], int n)
	{
		// Index of last non-leaf node
		int startIdx = (n / 2) - 1;

		// Perform reverse level order traversal
		// from last non-leaf node and heapify
		// each node
		for (int i = startIdx; i >= 0; i--) {
			heapify(arr, n, i);
		}
	}

	// A utility function to print the array
	// representation of Heap
	static void printHeap(int arr[], int n)
	{
		System.out.println("Array representation of Heap is:");

		for (int i = 0; i < n; ++i)
			System.out.print(arr[i] + " ");

		System.out.println();
	}

	// Driver Code
	public static void main(String args[])
	{
		int arr[] = { 1, 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16 };

		int n = arr.length;

		buildHeap(arr, n);

		printHeap(arr, n);
		
		System.out.println(comparisons + " C "+ "\n"+ swaps+ " S");
	}
}
