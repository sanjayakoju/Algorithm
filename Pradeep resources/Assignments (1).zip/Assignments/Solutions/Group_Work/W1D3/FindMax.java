package cs435assignment3;

public class FindMax {
	
	public static void main(String[] args) {
		
		System.out.println(beautiful(new int[] {1,89,35,45,12,4,56,98,125,3,24,11,9}));
		
	}
	
	
	static int beautiful(int [] a) {
		int max=a[0];
		for(int i=0; i<a.length; i++) {
			if(a[i]>max) {
				max=a[i];
			}
		}
		
		return max;
	}
	

}
