package cs435algorithms.assignment1;

import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Largest_Distance {

	public static void main(String[] args) {
		int [] a= new int[60000];
		
		//Random rc= new Random();
		for(int i=0; i<a.length; i++) {
			//a[i]=rc.nextInt(1000);
			a[i] = ThreadLocalRandom.current().nextInt(1, 40+1);
		}
		System.out.println();
		
		long start1 = System.currentTimeMillis();
		int maxDist1 =  algorithm3(a);
		long end1 = System.currentTimeMillis();
		System.out.println("running time algo1: "+ (end1- start1));
		
		long start2 = System.currentTimeMillis();
		int maxDist2 =  algorithm3(a);
		long end2= System.currentTimeMillis();
		System.out.println("running time algo2: "+ (end2- start2));
		
		long start3 = System.currentTimeMillis();
		int maxDist3 =  algorithm3(a);
		long end3 = System.currentTimeMillis();
		
		System.out.println("running time algo3: "+ (end3- start3));
		long start4 = System.currentTimeMillis();
		int maxDist4 =  algorithm3(a);
		long end4 = System.currentTimeMillis();
		System.out.println("running time algo4: "+ (end4- start4));	

	}

	public static int algorithm1(int[] a) {
		
		System.out.println("array a: "+ Arrays.toString(a));

		int[] b = new int[a.length];
		int counter = 0;
		for (int i = 0; i < a.length; i++) {
			if (a[i] % 2 == 0) {
				b[counter] = a[i];
				counter++;
				
				//System.out.println("counter: "+counter);
			}
			
		}
		//System.out.println("array b: "+ Arrays.toString(b));
		int[] evens = new int[counter];

		for (int i = 0; i < counter; i++) {
			evens[i] = b[i];

		}
		
		System.out.println(Arrays.toString(evens));
		int evenMin = evens[0];
		int evenMax = evens[1];
		for (int i = 0; i < evens.length; i++) {
			for (int j = 0; j < evens.length; j++) {
				if (evens[j] > evenMax) {
					evenMax = evens[j];
				}
				if (evens[i] < evenMin) {
					evenMin = evens[i];
				}

			}
			
		}
		//System.out.println("max: "+evenMax+ " min: "+ evenMin);
		return evenMax - evenMin;

	}

	public static int algorithm2(int[] a) {
		int evenMax = a[0];
		int evenMin = a[1];

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				if (a[j] % 2 == 0) {
					if (a[j] > evenMax) {
						evenMax = a[j];
					}
					if (a[i] < evenMin) {
						evenMin = a[i];
					}
				}

			}
		}
		

		return evenMax - evenMin;

	}

	public static int algorithm3(int[] a) {
		int evenMax = a[0];
		int evenMin = a[1];

		for (int i = 0; i < a.length; i++) {

			if (a[i] % 2 == 0) {
				if (a[i] > evenMax) {
					evenMax = a[i];
				}
				if (a[i] < evenMin) {
					evenMin = a[i];
				}
			}

		}

		

		return evenMax - evenMin;

	}

	public static int algorithm4(int[] a) {
		int max = Arrays.stream(a).filter(i -> i % 2 == 0).max().getAsInt();
		int min = Arrays.stream(a).filter(i -> i % 2 == 0).min().getAsInt();

		

		return max - min;

	}
}


